// update-movie.dto.ts
export class UpdateMovieDto {
  title?: string;
  publishingYear?: number;
  poster?: string;
}