// create-movie.dto.ts
export class CreateMovieDto {
  title: string;
  publishingYear: number;
  poster?: string;
}


